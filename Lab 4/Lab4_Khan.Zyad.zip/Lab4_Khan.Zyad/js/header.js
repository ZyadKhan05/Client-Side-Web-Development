header.innerHTML = ' <h1> <p id="header">Khan\'s Cookies </p> </h1> ' +
    '<h5> <input /> <button>Search</button></h5>';