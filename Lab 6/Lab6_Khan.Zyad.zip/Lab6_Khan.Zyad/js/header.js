header.innerHTML = ' <style>#header{\n' +
    '    font-size: 48px; \n' +
    '    background-color: aliceblue; \n' +
    '    color: brown; \n' +
    '    text-align: center;\n' +
    '    position: relative;\n' +
    '    overflow: unset;\n' +
    '\n' +
    '}</style>' +
    '       <link href="main.css" rel="stylesheet" type="text/css" /> ' +
    '<h1> <p id="header">Khan\'s Cookies </p> </h1> ' +
    '<h5> <input /> <button>Search</button></h5>'+
'<nav id="navbar_top" class="navbar navbar-expand-lg bg-dark navbar-dark">\n' +
    '            <a class="navbar-brand" href="index.html">\n' +
    '                <img src="https://static.vecteezy.com/system/resources/previews/003/789/380/original/homemade-oatmeal-cookie-with-chocolate-crumb-flat-style-traditional-chocolate-chip-cookie-for-logo-sticker-print-recipe-menu-package-bakery-design-and-decoration-vector.jpg" alt="Logo" style="width:55px;">\n' +
    '            </a>\n' +
    '            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">\n' +
    '                <span class="navbar-toggler-icon"></span>\n' +
    '            </button>\n' +
    '            <div class="collapse navbar-collapse " id="navbarSupportedContent">\n' +
    '                <div class="navbar-nav">\n' +
    '                    <ul class="list-group list-group-horizontal-md navbar-nav mr-auto mt-2 mt-lg-0 ">\n' +
    '                        <li class="list-group-item"><a href="index.html">Home</a> </li>\n' +
    '                        <li class="list-group-item"><a href="about.html">About Us</a></li>\n' +
    '                        <li class="list-group-item"><a href="contact.html">Contact Us</a></li>\n' +
    '                    </ul>\n' +
    '                </div>\n' +
    '              </div>\n' +
    '          </nav>';