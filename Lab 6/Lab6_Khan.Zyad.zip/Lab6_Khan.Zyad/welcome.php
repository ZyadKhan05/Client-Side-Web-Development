<?php echo $_GET['subject']; ?>
